﻿import xbmc
import xbmcgui
import xbmcvfs
import urllib.request
import zipfile
import os

# UPDATE THIS URL to point to your hosted KenandJays-Build.zip
BUILD_URL = "https://github.com/jjmandog12/venmons/releases/download/1.0/KenandJays-Build.zip"

def install_build():
    dialog = xbmcgui.DialogProgress()
    dialog.create("KenandJays Wizard", "Downloading Build...")

    # Download path
    dest_path = xbmcvfs.translatePath("special://home/")
    zip_path = os.path.join(dest_path, "temp_build.zip")

    # Hook for progress bar
    def report_hook(count, block_size, total_size):
        if dialog.iscanceled():
            return
        percent = int(count * block_size * 100 / total_size)
        if percent > 100:
            percent = 100
        dialog.update(percent, "Downloading Build... Please wait.", f"{percent}% Complete")

    try:
        # Download
        urllib.request.urlretrieve(BUILD_URL, zip_path, reporthook=report_hook)
        
        if dialog.iscanceled():
            if os.path.exists(zip_path):
                os.remove(zip_path)
            xbmcgui.Dialog().ok("Cancelled", "Build installation was cancelled.")
            return

        # Extract
        dialog.update(100, "Extracting Build...", "This might take a few minutes. Do not cancel.")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(dest_path)

        # Cleanup
        if os.path.exists(zip_path):
            os.remove(zip_path)
        
        dialog.close()
        
        # Force close Kodi
        xbmcgui.Dialog().ok("Success", "Build installed successfully!", "Click OK to force close Kodi. When you reopen Kodi, the build will be active.")
        xbmc.executebuiltin('Quit')

    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Error", "An error occurred:\n" + str(e))

if __name__ == '__main__':
    install_build()
