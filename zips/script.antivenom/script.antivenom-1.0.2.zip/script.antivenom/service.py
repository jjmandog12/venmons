# -*- coding: utf-8 -*-
"""
AntiVenom Background Service
Ensures AntiVenom skin is always active and Real-Debrid authorization is permanently remembered.
Includes automatic multi-location vault redundancy and seamless OAuth token refresh.
"""
import xbmc
import xbmcgui
import xbmcvfs
import os
import shutil
import json
import urllib.request
import urllib.parse
import urllib.error
import xml.etree.ElementTree as ET

RD_KEYS = [
    'RealDebridResolver_token',
    'RealDebridResolver_refresh',
    'RealDebridResolver_client_id',
    'RealDebridResolver_client_secret',
    'RealDebridResolver_enabled',
    'RealDebridResolver_login',
    'RealDebridResolver_torrents',
    'RealDebridResolver_priority',
    'RealDebridResolver_cached_only'
]

def ensure_skin_active():
    """Ensure skin.antivenom is deployed and actively running."""
    try:
        home_dir = xbmcvfs.translatePath('special://home/')
        addons_dir = os.path.join(home_dir, 'addons')
        skin_src = os.path.join(addons_dir, 'script.antivenom', 'skin.antivenom')
        skin_dest = os.path.join(addons_dir, 'skin.antivenom')

        # 1. Ensure skin.antivenom files are extracted and present in addons/
        if os.path.isdir(skin_src):
            if not os.path.isdir(skin_dest) or not os.path.isfile(os.path.join(skin_dest, 'addon.xml')):
                shutil.copytree(skin_src, skin_dest, dirs_exist_ok=True)
                xbmc.log('[AntiVenom] Service deployed skin.antivenom to addons folder!', xbmc.LOGINFO)
                xbmc.executebuiltin('UpdateLocalAddons')
                xbmc.sleep(1500)

        # 2. Check current active skin
        current_skin = xbmc.getSkinDir()
        xbmc.log(f'[AntiVenom] Service: active skin is {current_skin}', xbmc.LOGINFO)

        if current_skin != 'skin.antivenom':
            xbmc.log('[AntiVenom] Service: Default skin detected. Automatically switching to AntiVenom skin...', xbmc.LOGINFO)

            # Ensure skin.antivenom is enabled in Kodi
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': 'skin.antivenom', 'enabled': True}
            }))
            xbmc.sleep(500)

            # Update guisettings.xml directly without default="true"
            guisettings = xbmcvfs.translatePath('special://masterprofile/guisettings.xml')
            if os.path.isfile(guisettings):
                with open(guisettings, 'r', encoding='utf-8') as f:
                    content = f.read()
                import re
                if '<setting id="lookandfeel.skin"' in content:
                    content = re.sub(
                        r'<setting id="lookandfeel\.skin"[^>]*>[^<]*</setting>',
                        '<setting id="lookandfeel.skin">skin.antivenom</setting>',
                        content
                    )
                else:
                    content = content.replace('</settings>', '    <setting id="lookandfeel.skin">skin.antivenom</setting>\n</settings>')
                with open(guisettings, 'w', encoding='utf-8') as f:
                    f.write(content)

            # Trigger skin switch
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Settings.SetSettingValue',
                'params': {'setting': 'lookandfeel.skin', 'value': 'skin.antivenom'}
            }))

            # Auto-confirm Kodi's 15-second "Would you like to keep this change?" dialog
            for _ in range(8):
                xbmc.sleep(400)
                if xbmcgui.getCurrentWindowDialogId() == 10100:
                    xbmc.executebuiltin('SendClick(11)') # Click YES
                    break
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service skin activation error: {e}', xbmc.LOGWARNING)

def get_vault_paths():
    """Return all primary, secondary, and external device vault paths."""
    paths = [
        xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json'),
        xbmcvfs.translatePath('special://masterprofile/rd_vault.json'),
        xbmcvfs.translatePath('special://home/rd_vault.json')
    ]
    # FireStick & Android persistent storage paths (survives Kodi cache clear/reinstall)
    for p in [
        '/sdcard/AntiVenom_rd_vault.json',
        '/storage/emulated/0/AntiVenom_rd_vault.json',
        '/sdcard/Android/data/org.xbmc.kodi/files/rd_vault.json'
    ]:
        try:
            parent = os.path.dirname(p)
            if os.path.exists(parent):
                paths.append(p)
        except Exception:
            pass
    return paths

def read_vault_credentials():
    """Read saved credentials from any available vault file."""
    for vp in get_vault_paths():
        try:
            if os.path.isfile(vp):
                with open(vp, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if data.get('RealDebridResolver_token') or data.get('RealDebridResolver_refresh'):
                    return data
        except Exception:
            pass
    return None

def write_vault_credentials(creds):
    """Write credentials to all accessible vault locations for permanent persistence."""
    for vp in get_vault_paths():
        try:
            os.makedirs(os.path.dirname(vp), exist_ok=True)
            with open(vp, 'w', encoding='utf-8') as f:
                json.dump(creds, f, indent=4)
        except Exception:
            pass

def check_and_refresh_token(creds):
    """
    Checks token validity. If expired (401), automatically uses OAuth refresh_token
    to acquire a brand new token without prompting the user.
    """
    token = creds.get('RealDebridResolver_token')
    refresh = creds.get('RealDebridResolver_refresh')
    client_id = creds.get('RealDebridResolver_client_id', '763AE7OFYINMA')
    client_secret = creds.get('RealDebridResolver_client_secret', 'fbd4ae9583b0bca261644ef66534ebaa8ca481b7')

    if not token and not refresh:
        return creds, False

    need_refresh = False
    if token:
        try:
            req = urllib.request.Request(
                'https://api.real-debrid.com/rest/1.0/user',
                headers={'Authorization': f'Bearer {token}', 'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    username = data.get('username', 'Active User')
                    xbmc.executebuiltin(f'Skin.SetString(RealDebridUser,{username})')
                    return creds, False
        except urllib.error.HTTPError as e:
            if e.code == 401:
                need_refresh = True
            else:
                return creds, False
        except Exception:
            return creds, False
    else:
        need_refresh = True

    if need_refresh and refresh:
        try:
            post_data = urllib.parse.urlencode({
                'client_id': client_id,
                'client_secret': client_secret,
                'code': refresh,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }).encode('utf-8')
            req = urllib.request.Request(
                'https://api.real-debrid.com/oauth/v2/token',
                data=post_data,
                headers={'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                new_token = res.get('access_token')
                new_refresh = res.get('refresh_token') or refresh
                if new_token:
                    creds['RealDebridResolver_token'] = new_token
                    creds['RealDebridResolver_refresh'] = new_refresh
                    creds['RealDebridResolver_client_id'] = client_id
                    creds['RealDebridResolver_client_secret'] = client_secret
                    creds['RealDebridResolver_enabled'] = 'true'
                    creds['RealDebridResolver_login'] = 'true'
                    creds['RealDebridResolver_torrents'] = 'true'
                    creds['RealDebridResolver_cached_only'] = 'true'
                    creds['RealDebridResolver_priority'] = '50'
                    xbmc.log('[AntiVenom] Service: Successfully auto-refreshed Real-Debrid OAuth token!', xbmc.LOGINFO)
                    return creds, True
        except Exception as e:
            xbmc.log(f'[AntiVenom] Service: OAuth token refresh error: {e}', xbmc.LOGWARNING)

    return creds, False

def apply_to_resolveurl(creds):
    """Write credentials to ResolveURL settings.xml, ensuring it exists and is enabled."""
    try:
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        os.makedirs(os.path.dirname(resolveurl_settings), exist_ok=True)

        if os.path.isfile(resolveurl_settings):
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
        else:
            root = ET.Element('settings')
            tree = ET.ElementTree(root)

        existing = {s.attrib.get('id'): s for s in root.findall('setting')}
        changed = False

        for k, v in creds.items():
            if k in existing:
                if existing[k].text != str(v) or 'default' in existing[k].attrib:
                    existing[k].text = str(v)
                    if 'default' in existing[k].attrib:
                        del existing[k].attrib['default']
                    changed = True
            else:
                el = ET.SubElement(root, 'setting', {'id': k})
                el.text = str(v)
                changed = True

        if changed or not os.path.isfile(resolveurl_settings):
            tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)
            xbmc.log('[AntiVenom] Service: Synchronized Real-Debrid settings to ResolveURL.', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service apply_to_resolveurl error: {e}', xbmc.LOGWARNING)

def sync_rd():
    """Master Real-Debrid synchronization and persistent guardian."""
    try:
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        active_creds = None

        # 1. Read existing from ResolveURL if present
        if os.path.isfile(resolveurl_settings):
            try:
                tree = ET.parse(resolveurl_settings)
                root = tree.getroot()
                found = {}
                for s in root.findall('setting'):
                    sid = s.attrib.get('id')
                    if sid in RD_KEYS and s.text:
                        found[sid] = s.text.strip()
                if found.get('RealDebridResolver_token') and 'default' not in root.find(".//setting[@id='RealDebridResolver_token']").attrib:
                    active_creds = found
            except Exception:
                pass

        # 2. If ResolveURL lacked credentials, read from permanent multi-vault
        if not active_creds or not active_creds.get('RealDebridResolver_token'):
            active_creds = read_vault_credentials()

        if active_creds:
            # 3. Check and auto-refresh token if needed
            active_creds, refreshed = check_and_refresh_token(active_creds)

            # 4. Save into permanent multi-location vault
            write_vault_credentials(active_creds)

            # 5. Ensure ResolveURL is synced with current valid token
            apply_to_resolveurl(active_creds)

            # 6. Set skin status variables
            xbmc.executebuiltin('Skin.SetBool(RealDebridLinked)')
            xbmc.executebuiltin('Skin.SetBool(AntiVenom_RD_Active)')
            xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Active)')
            xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Label, "● REAL-DEBRID ACTIVE")')
            xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Color, "FF00F5A0")')
            return

        # No credentials anywhere
        xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
        xbmc.executebuiltin('Skin.Reset(AntiVenom_RD_Active)')
        xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
        xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Label, "○ CONNECT DEBRID")')
        xbmc.executebuiltin('Skin.SetString(AntiVenom_RD_Color, "FFA0AAB8")')
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service RD sync error: {e}', xbmc.LOGWARNING)

def check_first_run_wizard():
    """If this device has never completed setup and has no debrid credentials, prompt the setup wizard."""
    try:
        done_flag = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/.setup_complete')
        if not os.path.isfile(done_flag):
            xbmc.sleep(2500)
            if xbmcgui.getCurrentWindowId() == 10000:
                xbmc.log('[AntiVenom] First run on new device detected! Launching Setup Wizard...', xbmc.LOGINFO)
                xbmc.executebuiltin('RunScript(script.antivenom,action=setup_wizard,first_run=true)')
    except Exception as e:
        xbmc.log(f'[AntiVenom] First run check error: {e}', xbmc.LOGWARNING)

# ─────────────────────────────────────────────
#  Step 3: Playback Monitoring & Dynamic Resume Engine
# ─────────────────────────────────────────────
RESUME_FILE = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/resume_state.json')

def save_resume_state(state):
    try:
        os.makedirs(os.path.dirname(RESUME_FILE), exist_ok=True)
        with open(RESUME_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        xbmc.log(f'[AntiVenom Resume] Save error: {e}', xbmc.LOGWARNING)

def read_resume_state():
    try:
        if os.path.isfile(RESUME_FILE):
            with open(RESUME_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f'[AntiVenom Resume] Read error: {e}', xbmc.LOGWARNING)
    return None

def clear_resume_state():
    try:
        if os.path.isfile(RESUME_FILE):
            os.remove(RESUME_FILE)
    except Exception:
        pass
    clear_resume_to_skin()

def clear_resume_to_skin():
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Active)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Title)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Sub)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Thumb)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Time)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Seconds)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_BarWidth)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_Percent)')
    xbmc.executebuiltin('Skin.Reset(AntiVenom_Resume_File)')

def apply_resume_to_skin(state=None):
    if not state:
        state = read_resume_state()
    if state and state.get('active'):
        xbmc.executebuiltin('Skin.SetBool(AntiVenom_Resume_Active)')
        title = state.get('title', 'Last Watched').replace('"', '')
        sub = state.get('sub_label', 'Resume Playback').replace('"', '')
        thumb = state.get('thumb', '')
        time_str = state.get('time_str', '0:00')
        secs = str(state.get('seconds', 0))
        width = str(state.get('bar_width', 136))
        pct = str(state.get('percent', 50))
        file_path = state.get('file', '')

        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Title,"{title}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Sub,"{sub}")')
        if thumb:
            xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Thumb,"{thumb}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Time,"{time_str}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Seconds,"{secs}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_BarWidth,"{width}")')
        xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_Percent,"{pct}")')
        if file_path:
            xbmc.executebuiltin(f'Skin.SetString(AntiVenom_Resume_File,"{file_path}")')
    else:
        clear_resume_to_skin()

class AntiVenomPlayer(xbmc.Player):
    def __init__(self):
        super(AntiVenomPlayer, self).__init__()
        self.last_title = ""
        self.last_file = ""
        self.last_thumb = ""
        self.last_type = "movie"
        self.last_season = ""
        self.last_episode = ""

    def onAVStarted(self):
        try:
            self.last_title = xbmc.getInfoLabel('VideoPlayer.Title') or xbmc.getInfoLabel('Player.Title')
            self.last_file = self.getPlayingFile()
            self.last_thumb = (
                xbmc.getInfoLabel('Player.Art(poster)') or 
                xbmc.getInfoLabel('Player.Art(thumb)') or 
                xbmc.getInfoLabel('VideoPlayer.Cover') or
                xbmc.getInfoLabel('ListItem.Thumb')
            )
            self.last_season = xbmc.getInfoLabel('VideoPlayer.Season')
            self.last_episode = xbmc.getInfoLabel('VideoPlayer.Episode')
            if self.last_season and self.last_episode:
                self.last_type = "episode"
            else:
                self.last_type = "movie"
            xbmc.log(f'[AntiVenom Resume] Started playback: {self.last_title} ({self.last_type})', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'[AntiVenom Resume] onAVStarted error: {e}', xbmc.LOGWARNING)

    def onPlayBackPaused(self):
        self.record_progress()

    def onPlayBackStopped(self):
        self.record_progress()

    def onPlayBackEnded(self):
        self.mark_completed()

    def record_progress(self):
        try:
            curr_sec = int(self.getTime())
            total_sec = int(self.getTotalTime())
            if total_sec <= 0:
                return

            pct = (curr_sec / float(total_sec)) * 100.0

            # If watched between 2% and 92% (in-progress, not finished)
            if pct >= 2.0 and pct < 92.0:
                hrs = curr_sec // 3600
                mins = (curr_sec % 3600) // 60
                secs = curr_sec % 60
                if hrs > 0:
                    time_str = f"{hrs}:{mins:02d}:{secs:02d}"
                else:
                    time_str = f"{mins}:{secs:02d}"

                bar_width = max(10, min(272, int((pct / 100.0) * 272)))
                sub_label = f"Resume at {time_str} • {int(pct)}%"
                if self.last_season and self.last_episode:
                    sub_label = f"S{self.last_season} E{self.last_episode} • {time_str}"

                thumb = self.last_thumb
                if not thumb:
                    thumb = "special://home/addons/skin.antivenom/media/antivenom/posters/dune2.jpg"

                state = {
                    "active": True,
                    "title": self.last_title or "Last Watched Media",
                    "file": self.last_file,
                    "thumb": thumb,
                    "time_str": time_str,
                    "seconds": curr_sec,
                    "total_seconds": total_sec,
                    "percent": int(pct),
                    "bar_width": bar_width,
                    "sub_label": sub_label,
                    "type": self.last_type,
                    "season": self.last_season,
                    "episode": self.last_episode
                }
                save_resume_state(state)
                apply_resume_to_skin(state)
                xbmc.log(f'[AntiVenom Resume] Saved resume point for {self.last_title} at {time_str} ({int(pct)}%)', xbmc.LOGINFO)
            elif pct >= 92.0:
                self.mark_completed()
        except Exception as e:
            xbmc.log(f'[AntiVenom Resume] record_progress error: {e}', xbmc.LOGWARNING)

    def mark_completed(self):
        try:
            clear_resume_state()
            xbmc.log('[AntiVenom Resume] Playback ended/completed. Resume state cleared.', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'[AntiVenom Resume] mark_completed error: {e}', xbmc.LOGWARNING)

if __name__ == '__main__':
    xbmc.log('[AntiVenom] Background service started', xbmc.LOGINFO)
    ensure_skin_active()
    sync_rd()
    apply_resume_to_skin()
    check_first_run_wizard()

    player = AntiVenomPlayer()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
        sync_rd()
