import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json
import time
import shutil
import traceback
import urllib.request
import zipfile
import re

ADDON       = xbmcaddon.Addon()
ADDON_ID    = ADDON.getAddonInfo('id')
ADDON_PATH  = ADDON.getAddonInfo('path')
ADDON_DATA  = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
HOME_DIR    = xbmcvfs.translatePath('special://home/')
ADDONS_DIR  = os.path.join(HOME_DIR, 'addons')
SKIN_ID     = 'skin.antivenom'
SKIN_SRC    = os.path.join(ADDON_PATH, SKIN_ID)          # bundled inside our zip
SKIN_DEST   = os.path.join(ADDONS_DIR, SKIN_ID)          # where Kodi loads skins from
DONE_FLAG   = os.path.join(ADDON_DATA, '.setup_complete')

# Remote repository / version checking URL
UPDATE_URL = 'https://raw.githubusercontent.com/jjmandog12/venmons/main/version.json'
GITHUB_RELEASE_API = 'https://api.github.com/repos/jjmandog12/venmons/releases/latest'

def log(msg):
    xbmc.log(f'[AntiVenom] {msg}', xbmc.LOGINFO)

# ─────────────────────────────────────────────
#  Step 0: Force The Crew Netflix Views
# ─────────────────────────────────────────────
def force_views():
    try:
        import sqlite3
        views_db = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.thecrew/views.db')
        os.makedirs(os.path.dirname(views_db), exist_ok=True)
        conn = sqlite3.connect(views_db)
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS views (skin TEXT, view_type TEXT, view_id TEXT, UNIQUE(skin, view_type))')
        
        # 54 = InfoWall in our custom Estuary clone
        views = [
            ('skin.antivenom', 'movies', '500'),
            ('skin.antivenom', 'tvshows', '500'),
            ('skin.antivenom', 'seasons', '500'),
            ('skin.antivenom', 'episodes', '500')
        ]
        for record in views:
            c.execute('REPLACE INTO views (skin, view_type, view_id) VALUES (?, ?, ?)', record)
            
        conn.commit()
        conn.close()
        log('Forced Netflix Wall views (500) in The Crew DB!')

        # Also register visual InfoWall (131126 = 54) in Kodi's ViewModes6.db
        viewmodes_db = xbmcvfs.translatePath('special://profile/Database/ViewModes6.db')
        if os.path.isfile(viewmodes_db):
            vconn = sqlite3.connect(viewmodes_db)
            vc = vconn.cursor()
            paths = [
                'plugin://plugin.video.thecrew/?action=tvNetworks',
                'plugin://plugin.video.thecrew/?action=tvGenres',
                'plugin://plugin.video.thecrew/?action=movieGenres'
            ]
            for p in paths:
                vc.execute('INSERT OR REPLACE INTO view (window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) VALUES (?, ?, ?, ?, ?, ?, ?)',
                           (10025, p, 500, 0, 1, 0, 'skin.antivenom'))
            sports_paths = [
                'plugin://plugin.video.thecrew/?action=nfl',
                'plugin://plugin.video.thecrew/?action=ncaa',
                'plugin://plugin.video.thecrew/?action=cfb',
                'plugin://plugin.video.thecrew/?action=nba',
                'plugin://plugin.video.thecrew/?action=ncaab',
                'plugin://plugin.video.thecrew/?action=college_sports',
                'plugin://plugin.video.thecrew/?action=mlb',
                'plugin://plugin.video.thecrew/?action=ufc',
                'plugin://plugin.video.thecrew/?action=streamed_basketball',
                'plugin://plugin.video.thecrew/?action=streamed_basketball&content=addons&url=basketball',
                'plugin://plugin.video.thecrew/?action=streamed_basketball&content=videos&url=basketball',
                'plugin://plugin.video.thecrew/?action=streamed_baseball',
                'plugin://plugin.video.thecrew/?action=streamed_baseball&content=addons&url=baseball',
                'plugin://plugin.video.thecrew/?action=streamed_baseball&content=videos&url=baseball',
                'plugin://plugin.video.thecrew/?action=streamed_fight',
                'plugin://plugin.video.thecrew/?action=streamed_fight&content=addons&url=fight',
                'plugin://plugin.video.thecrew/?action=streamed_fight&content=videos&url=fight',
                'plugin://plugin.video.thecrew/?action=streamed_football',
                'plugin://plugin.video.thecrew/?action=streamed_football&content=addons&url=american-football',
                'plugin://plugin.video.thecrew/?action=streamed_football&content=videos&url=american-football',
                'plugin://plugin.video.thecrew/?action=bluehat',
                'plugin://plugin.video.thecrew/?action=fifa',
                'plugin://plugin.video.thecrew/?action=f1',
                'plugin://plugin.video.thecrew/?action=boxing',
                'plugin://plugin.video.thecrew/?action=nhl',
                'plugin://plugin.video.thecrew/?action=wwe',
                'plugin://plugin.video.thecrew/?action=nascar',
                'plugin://plugin.video.thecrew/?action=sports_channels',
                'plugin://plugin.video.thecrew/?action=sreplays'
            ]
            for sp in sports_paths:
                vc.execute('INSERT OR REPLACE INTO view (window, path, viewMode, sortMethod, sortOrder, sortAttributes, skin) VALUES (?, ?, ?, ?, ?, ?, ?)',
                           (10025, sp, 500, 0, 1, 0, 'skin.antivenom'))
            vconn.commit()
            vconn.close()
            log('Forced Netflix Wall view modes (500) in ViewModes6.db!')
    except Exception as e:
        log(f'Failed to force views: {e}')

# ─────────────────────────────────────────────
#  Step 1: Install skin.antivenom + switch to it
# ─────────────────────────────────────────────
def install_skin():
    """Copy the bundled skin.antivenom into Kodi's addons folder and activate it."""
    if not os.path.isdir(SKIN_SRC):
        log(f'Bundled skin not found at {SKIN_SRC}')
        return False

    try:
        if os.path.isdir(SKIN_DEST):
            shutil.rmtree(SKIN_DEST)
        shutil.copytree(SKIN_SRC, SKIN_DEST)
        log(f'Installed skin to {SKIN_DEST}')

        # Tell Kodi about the new addon
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(1500)

        # Force enable the addon so Kodi doesn't reject it
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.SetAddonEnabled',
            'params': {'addonid': SKIN_ID, 'enabled': True}
        }))
        xbmc.sleep(500)

        # Switch skin via Settings API
        result = xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin', 'value': SKIN_ID}
        }))
        log(f'Skin switch result: {result}')

        # Disable ugly parent folder ".." items across Kodi
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Settings.SetSettingValue',
            'params': {'setting': 'filelists.showparentdiritems', 'value': False}
        }))

        # Also write it to guisettings.xml as a belt-and-suspenders fix
        guisettings = xbmcvfs.translatePath('special://masterprofile/guisettings.xml')
        if os.path.isfile(guisettings):
            content = open(guisettings, 'r', encoding='utf-8').read()
            import re
            content = re.sub(
                r'<setting id="lookandfeel\.skin"[^>]*>[^<]*</setting>',
                f'<setting id="lookandfeel.skin">{SKIN_ID}</setting>',
                content
            )
            content = re.sub(
                r'<setting id="filelists\.showparentdiritems"[^>]*>[^<]*</setting>',
                '<setting id="filelists.showparentdiritems">false</setting>',
                content
            )
            open(guisettings, 'w', encoding='utf-8').write(content)
            log('Updated guisettings.xml skin and filelists entries')

        # Auto-confirm Kodi's 15-second "Would you like to keep this change?" dialog
        for _ in range(8):
            xbmc.sleep(400)
            if xbmcgui.getCurrentWindowDialogId() == 10100:
                xbmc.executebuiltin('SendClick(11)') # YES
                break

        xbmc.sleep(1000)
        return True
    except Exception as e:
        log(f'Skin install error: {e}\n{traceback.format_exc()}')
        return False

# ─────────────────────────────────────────────
#  Step 2: Install streaming addons
# ─────────────────────────────────────────────
def install_streaming_addons(progress, step, total):
    REPOS = [
        ('The Crew Repository',
         'https://team-crew.github.io/repository.thecrew-0.3.8.zip',
         'repository.thecrew'),
    ]
    for name, url, repo_id in REPOS:
        step += 1
        progress.update(int(step/total*100), f'Downloading {name}...')
        if progress.iscanceled(): return step
        repo_dir = os.path.join(ADDONS_DIR, repo_id)
        if not os.path.isdir(repo_dir):
            try:
                tmp = os.path.join(HOME_DIR, f'_av_{repo_id}.zip')
                urllib.request.urlretrieve(url, tmp)
                with zipfile.ZipFile(tmp, 'r') as z:
                    z.extractall(ADDONS_DIR)
                if os.path.exists(tmp):
                    os.remove(tmp)
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0', 'id': 1,
                    'method': 'Addons.SetAddonEnabled',
                    'params': {'addonid': repo_id, 'enabled': True}
                }))
            except Exception as e:
                log(f'Repo install error: {e}')

    step += 1
    progress.update(int(step/total*100), 'Refreshing addon list...')
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.sleep(3000)

    for addon_id in ['plugin.video.thecrew', 'pvr.iptvsimple', 'script.module.pycryptodome']:
        if not os.path.isdir(os.path.join(ADDONS_DIR, addon_id)):
            xbmc.executebuiltin(f'InstallAddon({addon_id})')
            xbmc.sleep(5000)

    return step

# ─────────────────────────────────────────────
#  Step 3: Configure US Live TV
# ─────────────────────────────────────────────
def configure_iptv(progress, step, total):
    step += 1
    progress.update(int(step/total*100), 'Configuring US Live TV...')
    pvr_data = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple/')
    os.makedirs(pvr_data, exist_ok=True)
    m3u_path = xbmcvfs.translatePath('special://home/addons/script.antivenom/resources/custom_tv.m3u')
    epg_path = xbmcvfs.translatePath('special://home/addons/script.antivenom/resources/epg.xml')
    settings = (
        '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
        '<settings version="2">\n'
        f'  <setting id="m3uPath">{m3u_path}</setting>\n'
        '  <setting id="m3uPathType">0</setting>\n'
        f'  <setting id="epgPath">{epg_path}</setting>\n'
        '  <setting id="epgPathType">0</setting>\n'
        '</settings>\n'
    )
    with open(os.path.join(pvr_data, 'settings.xml'), 'w', encoding='utf-8') as f:
        f.write(settings)
        
    # Kodi 20+ directly reads instance-settings-1.xml in pvr.iptvsimple/
    instance_settings = (
        '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
        '<settings version="2">\n'
        '  <setting id="kodi_addon_instance_name">Migrated Add-on Config</setting>\n'
        '  <setting id="kodi_addon_instance_enabled">true</setting>\n'
        '  <setting id="m3uPathType">0</setting>\n'
        f'  <setting id="m3uPath">{m3u_path}</setting>\n'
        '  <setting id="m3uUrl"></setting>\n'
        '  <setting id="m3uCache">false</setting>\n'
        f'  <setting id="epgPath">{epg_path}</setting>\n'
        '  <setting id="epgPathType">0</setting>\n'
        '  <setting id="epgCache">false</setting>\n'
        '</settings>\n'
    )
    with open(os.path.join(pvr_data, 'instance-settings-1.xml'), 'w', encoding='utf-8') as f:
        f.write(instance_settings)

    # Clean up old m3u cache files and any stray subdirectories
    for f_name in os.listdir(pvr_data):
        if 'cache' in f_name:
            try:
                os.remove(os.path.join(pvr_data, f_name))
            except Exception:
                pass

    instances_dir = os.path.join(pvr_data, 'instances')
    if os.path.exists(instances_dir):
        import shutil
        try:
            shutil.rmtree(instances_dir)
        except Exception as e:
            log(f"Failed to delete PVR instances dir: {e}")

    return step

# ─────────────────────────────────────────────
#  Step 4: Firestick Zero-Buffering & Multi-Scraper Config
# ─────────────────────────────────────────────
def configure_advancedsettings():
    """Deploy zero-buffering 100MB RAM cache settings optimized for Firestick."""
    try:
        master_profile = xbmcvfs.translatePath('special://masterprofile/')
        os.makedirs(master_profile, exist_ok=True)
        adv_dest = os.path.join(master_profile, 'advancedsettings.xml')
        adv_src = os.path.join(ADDON_PATH, 'resources', 'advancedsettings.xml')
        if os.path.isfile(adv_src):
            shutil.copy2(adv_src, adv_dest)
            log(f'Deployed advancedsettings.xml to {adv_dest}')
        else:
            content = '''<advancedsettings version="1.0">
  <cache>
    <buffermode>1</buffermode>
    <memorysize>104857600</memorysize>
    <readfactor>20</readfactor>
  </cache>
  <network>
    <curlclienttimeout>15</curlclienttimeout>
    <curllowspeedtime>10</curllowspeedtime>
    <curlretries>2</curlretries>
    <disableipv6>true</disableipv6>
    <curlkeepalive>true</curlkeepalive>
  </network>
  <video>
    <busydialogdelay>500</busydialogdelay>
    <enablehighqualityh264>true</enablehighqualityh264>
  </video>
  <gui>
    <algorithmdirtyregions>3</algorithmdirtyregions>
    <nofliptimeout>0</nofliptimeout>
  </gui>
  <freelibrarycleaner>true</freelibrarycleaner>
  <loglevel hide="true">-1</loglevel>
</advancedsettings>'''
            with open(adv_dest, 'w', encoding='utf-8') as f:
                f.write(content)
            log('Created fallback advancedsettings.xml')

        # Kodi 21.3 Omega native GUI cache settings (Settings -> Services -> Caching)
        kodi21_cache = {
            'filecache.buffermode': 1,
            'filecache.memorysize': 100,
            'filecache.readfactor': 2000,
            'filecache.chunksize': 262144
        }
        for k, v in kodi21_cache.items():
            try:
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0', 'id': 1,
                    'method': 'Settings.SetSettingValue',
                    'params': {'setting': k, 'value': v}
                }))
            except Exception:
                pass

        # Also persist directly into guisettings.xml for Kodi 21.3
        guisettings = os.path.join(master_profile, 'guisettings.xml')
        if os.path.isfile(guisettings):
            try:
                import xml.etree.ElementTree as ET
                tree = ET.parse(guisettings)
                root = tree.getroot()
                existing = {s.attrib.get('id'): s for s in root.findall('setting')}
                for sid, val in kodi21_cache.items():
                    sval = str(val)
                    if sid in existing:
                        existing[sid].text = sval
                        if 'default' in existing[sid].attrib:
                            del existing[sid].attrib['default']
                    else:
                        el = ET.SubElement(root, 'setting', {'id': sid})
                        el.text = sval
                tree.write(guisettings, encoding='utf-8', xml_declaration=False)
                log('Kodi 21.3 native caching settings persisted to guisettings.xml')
            except Exception as e:
                log(f'Failed to write Kodi 21.3 cache to guisettings.xml: {e}')

        return True
    except Exception as e:
        log(f'Error configuring advancedsettings: {e}')
        return False

def configure_multiscraper():
    """Activate all 5 provider networks in The Crew for unified multi-scraper link discovery."""
    try:
        crew_settings = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.thecrew/settings.xml')
        if not os.path.isfile(crew_settings):
            return False
        import xml.etree.ElementTree as ET
        tree = ET.parse(crew_settings)
        root = tree.getroot()
        changes = {
            'crewscrapers.enabled': 'true',
            'classyscrapers.enabled': 'true',
            'gearsscrapers.enabled': 'true',
            'cocoscrapers.enabled': 'true',
            'viperscrapers.enabled': 'true',
            'magneto.enabled': 'true',
            'debrid.only': 'false',
            'torrent.enabled': 'true',
            'scrapers.timeout.1': '15',
            'hosts.mode': '1'
        }
        existing = {s.attrib.get('id'): s for s in root.findall('setting')}
        for sid, val in changes.items():
            if sid in existing:
                existing[sid].text = val
            else:
                el = ET.SubElement(root, 'setting', {'id': sid})
                el.text = val
        tree.write(crew_settings, encoding='utf-8', xml_declaration=True)
        log('Multi-scraper engines (Crew + Classy + Gears + Coco + Viper + Magneto + Debrid + Free) activated!')
        return True
    except Exception as e:
        log(f'Error configuring multi-scraper: {e}')
        return False

def clean_system_cache(silent=False):
    """Purge temporary video fragments, package zips, and scraper cache to keep Firestick fast."""
    freed_bytes = 0
    cleaned_items = 0
    try:
        # 1. Clean packages folder
        pkg_dir = xbmcvfs.translatePath('special://home/addons/packages/')
        if os.path.isdir(pkg_dir):
            for f in os.listdir(pkg_dir):
                fp = os.path.join(pkg_dir, f)
                try:
                    freed_bytes += os.path.getsize(fp)
                    os.remove(fp)
                    cleaned_items += 1
                except Exception:
                    pass

        # 2. Clean temp folder
        temp_dir = xbmcvfs.translatePath('special://temp/')
        if os.path.isdir(temp_dir):
            for f in os.listdir(temp_dir):
                if f.endswith(('.log', '.fi', '.tmp', '.zip')):
                    fp = os.path.join(temp_dir, f)
                    try:
                        freed_bytes += os.path.getsize(fp)
                        os.remove(fp)
                        cleaned_items += 1
                    except Exception:
                        pass

        # 3. Clean The Crew caches via plugin action
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.thecrew/?action=clearAllCache)')

        freed_mb = freed_bytes / (1024 * 1024)
        log(f'Cleaned {cleaned_items} items, freed {freed_mb:.1f} MB')

        if not silent:
            xbmcgui.Dialog().notification(
                'AntiVenom Cleaner',
                f'✓ System Cleaned! Freed {freed_mb:.1f} MB — Firestick Optimized',
                xbmcgui.NOTIFICATION_INFO,
                4000
            )
        return True
    except Exception as e:
        log(f'Clean error: {e}')
        if not silent:
            xbmcgui.Dialog().notification('AntiVenom Cleaner', '✓ Cache Cleared', xbmcgui.NOTIFICATION_INFO, 2000)
        return False

# ─────────────────────────────────────────────
#  Full first-run setup
# ─────────────────────────────────────────────
def run_setup():
    if os.path.exists(DONE_FLAG):
        return True

    progress = xbmcgui.DialogProgress()
    progress.create('AntiVenom Hub', 'Setting up your hub — please wait...')
    try:
        total = 8
        step = 0

        step += 1
        progress.update(int(step/total*100), 'Forcing Netflix views...')
        force_views()

        step += 1
        progress.update(int(step/total*100), 'Installing AntiVenom skin...')
        install_skin()

        step = install_streaming_addons(progress, step, total)
        step = configure_iptv(progress, step, total)

        step += 1
        progress.update(int(step/total*100), 'Applying Zero-Buffering & Multi-Scraper Config...')
        configure_advancedsettings()
        configure_multiscraper()
        clean_system_cache(silent=True)

        step += 1
        progress.update(100, 'Setup complete!')
        xbmc.sleep(1000)
        progress.close()

        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(DONE_FLAG, 'w') as f:
            f.write(str(time.time()))

        xbmcgui.Dialog().notification(
            'AntiVenom Hub', '✓ Setup complete! Restarting to apply your new skin...',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmc.sleep(3000)

        # Restart Kodi to apply the new skin
        xbmc.executebuiltin('RestartApp')
        return True

    except Exception as e:
        progress.close()
        log(f'Setup error: {e}\n{traceback.format_exc()}')
        xbmcgui.Dialog().ok('AntiVenom Error', f'Setup failed:\n{e}')
        return False

# ─────────────────────────────────────────────
#  Action Handlers (called from skin buttons)
# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
#  Action Handlers (called from skin buttons)
# ─────────────────────────────────────────────
def action_setup_wizard(first_run=False):
    dialog = xbmcgui.Dialog()

    welcome_text = (
        "[COLOR #00F5A0][B]Welcome to AntiVenom (v4.0.0 Cyber-Luxe Edition)![/B][/COLOR]\n\n"
        "Engineered for high-speed 60 FPS streaming on Amazon FireStick & Android TV.\n\n"
        "To ensure [B]buffer-free 4K HDR & Dolby Atmos streaming[/B] without account sharing bans, "
        "each device connects its own Real-Debrid account.\n\n"
        "Would you like to run the quick setup wizard now?"
    )

    if not dialog.yesno('AntiVenom — Setup Wizard', welcome_text, yeslabel='Start Setup', nolabel='Skip Wizard'):
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(DONE_FLAG, 'w') as f:
            f.write(str(time.time()))
        xbmc.executebuiltin('Skin.SetBool(AntiVenomSetupComplete)')
        return

    # Step 1: Real-Debrid
    rd_choices = [
        '🔑  [COLOR #00F5A0][B]Pair My Real-Debrid Account[/B][/COLOR]  (Recommended for 4K)',
        '⚡  [COLOR #00D2FF]I Have AllDebrid / Premiumize[/COLOR]  (Universal Resolver)',
        '🌐  [COLOR lightgray]Skip / Use Free Multi-Scrapers[/COLOR]  (No Debrid Account)'
    ]
    rd_sel = dialog.select('AntiVenom — Step 1/2: Real-Debrid Account', rd_choices, preselect=0)

    if rd_sel == 0:
        dialog.ok(
            'Pairing Real-Debrid',
            "A pairing popup with your device code will appear in a moment.\n\n"
            "1. On your phone or computer, open:\n"
            "   [COLOR #00D2FF][B]https://real-debrid.com/device[/B][/COLOR]\n\n"
            "2. Enter the code shown on your TV screen.\n\n"
            "3. Once approved, AntiVenom locks your credentials into your device vault permanently!"
        )
        xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

        # Monitor for token capture for up to 90 seconds
        progress = xbmcgui.DialogProgress()
        progress.create('Real-Debrid Pairing', 'Waiting for approval at https://real-debrid.com/device...')
        linked = False
        for i in range(45):
            xbmc.sleep(2000)
            if progress.iscanceled():
                break
            progress.update(int((i / 45) * 100), f'Waiting for authorization from https://real-debrid.com/device...\nTime remaining: {90 - (i * 2)}s')
            if sync_realdebrid_vault():
                linked = True
                break
        progress.close()

        if linked:
            dialog.ok(
                'Real-Debrid Activated!',
                "[COLOR #00F5A0][B]✓ Real-Debrid successfully linked and permanently saved![/B][/COLOR]\n\n"
                "Your device will remember your account forever across all reboots and updates."
            )
        else:
            dialog.notification('Real-Debrid', 'You can link your account anytime in Settings -> Real-Debrid Hub.', xbmcgui.NOTIFICATION_INFO, 4000)

    elif rd_sel == 1:
        xbmc.executebuiltin('Addon.OpenSettings(script.module.resolveurl)')
    elif rd_sel == 2:
        dialog.ok(
            'Free Scrapers Configured',
            "Free multi-scraper engines are enabled!\n\n"
            "You can stream movies, TV shows, and live TV immediately.\n"
            "To unlock 4K remuxes anytime, visit Settings -> Real-Debrid Hub."
        )

    # Step 2: Device Performance Optimization
    cache_choices = [
        '🔥  [COLOR #00F5A0][B]Amazon FireStick / Fire TV[/B][/COLOR]  (150MB Zero-Stutter Cache)',
        '📺  [COLOR #00D2FF]Android TV / Shield / Google TV[/COLOR]  (300MB High-RAM Cache)',
        '💻  [COLOR lightgray]PC / Mac / Mini PC[/COLOR]  (500MB High-Speed Cache)',
        '⏭  [COLOR darkgray]Default Kodi Settings[/COLOR]'
    ]
    c_sel = dialog.select('AntiVenom — Step 2/2: Device Tuning', cache_choices, preselect=0)
    if c_sel == 0:
        configure_advancedsettings(size_mb=150)
    elif c_sel == 1:
        configure_advancedsettings(size_mb=300)
    elif c_sel == 2:
        configure_advancedsettings(size_mb=500)

    # Finalize
    force_views()
    configure_multiscraper()

    os.makedirs(ADDON_DATA, exist_ok=True)
    with open(DONE_FLAG, 'w') as f:
        f.write(str(time.time()))
    xbmc.executebuiltin('Skin.SetBool(AntiVenomSetupComplete)')

    dialog.ok(
        'Setup Complete!',
        "[COLOR #00F5A0][B]AntiVenom is ready for your living room![/B][/COLOR]\n\n"
        "• Autocomplete Search: [COLOR #00D2FF]Active[/COLOR]\n"
        "• Stream Scrapers: [COLOR #00D2FF]Ready[/COLOR]\n"
        "• 10-Foot Remote Navigation: [COLOR #00D2FF]Enabled[/COLOR]\n\n"
        "Enjoy your movies, shows, and live TV!"
    )
    xbmc.executebuiltin('ActivateWindow(Home)')

def action_setup():
    dialog = xbmcgui.Dialog()
    choice = dialog.select('AntiVenom Settings', [
        '🧙  Launch Setup Wizard (Pair Real-Debrid & Tune Cache)',
        '🔑  Manage Real-Debrid (Status, Re-auth, Vault)',
        '🎨  Activate AntiVenom Skin',
        '📺  Refresh Live TV Guide',
        '🧹  Clear System & Resolver Cache',
        '⏻  Exit AntiVenom',
        'Close'
    ])
    if choice == 0:
        action_setup_wizard(first_run=False)
    elif choice == 1:
        action_manage_debrid()
    elif choice == 2:
        install_skin()
        dialog.ok('AntiVenom Skin', 'AntiVenom custom theme has been activated!')
    elif choice == 3:
        xbmc.executebuiltin('RunPlugin(plugin://pvr.iptvsimple/?mode=update)')
    elif choice == 4:
        clean_system_cache(silent=False)
    elif choice == 5:
        xbmc.executebuiltin('Quit')

# ─────────────────────────────────────────────
#  Real-Debrid Permanent Vault & Manager
# ─────────────────────────────────────────────
def get_rd_vault_paths():
    paths = [
        xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json'),
        xbmcvfs.translatePath('special://masterprofile/rd_vault.json'),
        xbmcvfs.translatePath('special://home/rd_vault.json')
    ]
    for p in ['/sdcard/AntiVenom_rd_vault.json', '/storage/emulated/0/AntiVenom_rd_vault.json', '/sdcard/Android/data/org.xbmc.kodi/files/rd_vault.json']:
        try:
            if os.path.exists(os.path.dirname(p)):
                paths.append(p)
        except Exception:
            pass
    return paths

def check_and_refresh_rd_token(creds):
    token = creds.get('RealDebridResolver_token')
    refresh = creds.get('RealDebridResolver_refresh')
    client_id = creds.get('RealDebridResolver_client_id', '763AE7OFYINMA')
    client_secret = creds.get('RealDebridResolver_client_secret', 'fbd4ae9583b0bca261644ef66534ebaa8ca481b7')

    if not token and not refresh:
        return creds, False

    need_refresh = False
    if token:
        try:
            import urllib.request, urllib.error
            req = urllib.request.Request(
                'https://api.real-debrid.com/rest/1.0/user',
                headers={'Authorization': f'Bearer {token}', 'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    username = data.get('username', 'Active User')
                    xbmc.executebuiltin(f'Skin.SetString(RealDebridUser,{username})')
                    return creds, False
        except urllib.error.HTTPError as e:
            if e.code == 401:
                need_refresh = True
            else:
                return creds, False
        except Exception:
            return creds, False
    else:
        need_refresh = True

    if need_refresh and refresh:
        try:
            import urllib.request, urllib.parse
            post_data = urllib.parse.urlencode({
                'client_id': client_id,
                'client_secret': client_secret,
                'code': refresh,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }).encode('utf-8')
            req = urllib.request.Request(
                'https://api.real-debrid.com/oauth/v2/token',
                data=post_data,
                headers={'User-Agent': 'AntiVenom/4.0'}
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                new_token = res.get('access_token')
                new_refresh = res.get('refresh_token') or refresh
                if new_token:
                    creds['RealDebridResolver_token'] = new_token
                    creds['RealDebridResolver_refresh'] = new_refresh
                    creds['RealDebridResolver_client_id'] = client_id
                    creds['RealDebridResolver_client_secret'] = client_secret
                    creds['RealDebridResolver_enabled'] = 'true'
                    creds['RealDebridResolver_login'] = 'true'
                    creds['RealDebridResolver_torrents'] = 'true'
                    creds['RealDebridResolver_cached_only'] = 'true'
                    creds['RealDebridResolver_priority'] = '50'
                    return creds, True
        except Exception as e:
            log(f'RD OAuth refresh error: {e}')

    return creds, False

def sync_realdebrid_vault():
    """Sync ResolveURL credentials with multi-location permanent vault and auto-refresh."""
    try:
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
        rd_keys = [
            'RealDebridResolver_token',
            'RealDebridResolver_refresh',
            'RealDebridResolver_client_id',
            'RealDebridResolver_client_secret',
            'RealDebridResolver_enabled',
            'RealDebridResolver_login',
            'RealDebridResolver_torrents',
            'RealDebridResolver_priority',
            'RealDebridResolver_cached_only'
        ]

        active_creds = None
        if os.path.isfile(resolveurl_settings):
            import xml.etree.ElementTree as ET
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
            token_node = None
            for s in root.findall('setting'):
                if s.attrib.get('id') == 'RealDebridResolver_token':
                    token_node = s
                    break

            if token_node is not None and token_node.text and 'default' not in token_node.attrib and token_node.text.strip():
                saved = {}
                for s in root.findall('setting'):
                    sid = s.attrib.get('id')
                    if sid in rd_keys and s.text:
                        saved[sid] = s.text.strip()
                if saved.get('RealDebridResolver_token'):
                    active_creds = saved

        # If ResolveURL lacked credentials, read from any vault
        if not active_creds:
            for vp in get_rd_vault_paths():
                try:
                    if os.path.isfile(vp):
                        with open(vp, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                        if data.get('RealDebridResolver_token') or data.get('RealDebridResolver_refresh'):
                            active_creds = data
                            break
                except Exception:
                    pass

        if active_creds:
            # Check and auto-refresh token if expired
            active_creds, refreshed = check_and_refresh_rd_token(active_creds)

            # Save to all vault locations
            for vp in get_rd_vault_paths():
                try:
                    os.makedirs(os.path.dirname(vp), exist_ok=True)
                    with open(vp, 'w', encoding='utf-8') as f:
                        json.dump(active_creds, f, indent=4)
                except Exception:
                    pass

            # Write to ResolveURL settings
            os.makedirs(os.path.dirname(resolveurl_settings), exist_ok=True)
            import xml.etree.ElementTree as ET
            if os.path.isfile(resolveurl_settings):
                tree = ET.parse(resolveurl_settings)
                root = tree.getroot()
            else:
                root = ET.Element('settings')
                tree = ET.ElementTree(root)

            existing = {s.attrib.get('id'): s for s in root.findall('setting')}
            changed = False
            for k, v in active_creds.items():
                if k in existing:
                    if existing[k].text != str(v) or 'default' in existing[k].attrib:
                        existing[k].text = str(v)
                        if 'default' in existing[k].attrib:
                            del existing[k].attrib['default']
                        changed = True
                else:
                    el = ET.SubElement(root, 'setting', {'id': k})
                    el.text = str(v)
                    changed = True

            if changed or not os.path.isfile(resolveurl_settings):
                tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)

            xbmc.executebuiltin('Skin.SetBool(RealDebridLinked)')
            xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Active)')
            return True

        xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
        xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
        return False
    except Exception as e:
        log(f'RD Vault sync error: {e}')
        return False

def action_manage_debrid():
    dialog = xbmcgui.Dialog()
    is_linked = sync_realdebrid_vault()

    if is_linked:
        vault_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json')
        options = [
            '✅  Status: Active & Remembered (Permanent)',
            '🔄  Re-Authorize Real-Debrid (Pair New Code / Device)',
            '💾  Save / Lock Current Credentials to Vault',
            '⚙  Open ResolveURL Debrid & Scraper Settings',
            '🗑  Clear / Disconnect Real-Debrid Account'
        ]
        sel = dialog.select('AntiVenom — Real-Debrid Hub', options)
        if sel == 0:
            dialog.ok('Real-Debrid Active', 'Your Real-Debrid account is active and permanently saved!\n\nAntiVenom automatically restores your authorization every time Kodi launches or updates, so you never have to sign in again.')
        elif sel == 1:
            xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')
        elif sel == 2:
            sync_realdebrid_vault()
            dialog.ok('Credentials Saved', 'Your Real-Debrid token has been locked into the secure vault:\nrd_vault.json\n\nIt will persist forever across all updates.')
        elif sel == 3:
            xbmc.executebuiltin('Addon.OpenSettings(script.module.resolveurl)')
        elif sel == 4:
            if dialog.yesno('Disconnect Real-Debrid', 'Are you sure you want to disconnect and wipe saved Real-Debrid credentials?'):
                try:
                    if os.path.exists(vault_file):
                        os.remove(vault_file)
                    resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')
                    if os.path.isfile(resolveurl_settings):
                        import xml.etree.ElementTree as ET
                        tree = ET.parse(resolveurl_settings)
                        root = tree.getroot()
                        for s in list(root.findall('setting')):
                            if 'RealDebrid' in s.attrib.get('id', ''):
                                root.remove(s)
                        tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)
                    xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
                    xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
                    dialog.ok('Disconnected', 'Real-Debrid has been removed.')
                except Exception as e:
                    dialog.ok('Error', f'Failed to disconnect: {e}')
    else:
        if dialog.yesno('Authorize Real-Debrid', 
                        'Real-Debrid provides instant multi-gigabit 4K/1080p cached torrent streams with zero buffering.\n\nWould you like to authorize your Real-Debrid account now?\n(AntiVenom will permanently remember your login!)',
                        nolabel='Cancel', yeslabel='Authorize Now'):
            xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

# ─────────────────────────────────────────────
#  Search & Category Handlers
# ─────────────────────────────────────────────
def _get_search_db():
    for f in ['search.1.db', 'search.db']:
        p = xbmcvfs.translatePath(f'special://profile/addon_data/plugin.video.thecrew/{f}')
        if os.path.exists(p):
            return p
    return None

def action_search_movies():
    kb = xbmc.Keyboard('', 'Search Movies & Blockbusters')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText().strip()
        if query:
            import urllib.parse
            target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(query)}'
            if xbmcgui.getCurrentWindowId() == 10025:
                xbmc.executebuiltin(f'Container.Update({target})')
            else:
                xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
                _force_wall_view()

def action_search_shows():
    kb = xbmc.Keyboard('', 'Search TV Shows & Streaming Exclusives')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText().strip()
        if query:
            import urllib.parse
            target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(query)}'
            if xbmcgui.getCurrentWindowId() == 10025:
                xbmc.executebuiltin(f'Container.Update({target})')
            else:
                xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
                _force_wall_view()

def action_universal_search():
    kb = xbmc.Keyboard('', 'Search All Movies, TV Shows & Streaming Exclusives')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText().strip()
        if query:
            import urllib.parse
            encoded = urllib.parse.quote_plus(query)
            dialog = xbmcgui.Dialog()
            options = [
                f'📺  Search TV Shows & Streaming Exclusives for "{query}"',
                f'🎬  Search Movies & Blockbusters for "{query}"'
            ]
            choice = dialog.select(f'AntiVenom Search — "{query}"', options)
            if choice == 0:
                target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={encoded}'
                if xbmcgui.getCurrentWindowId() == 10025:
                    xbmc.executebuiltin(f'Container.Update({target})')
                else:
                    xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
                    _force_wall_view()
            elif choice == 1:
                target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={encoded}'
                if xbmcgui.getCurrentWindowId() == 10025:
                    xbmc.executebuiltin(f'Container.Update({target})')
                else:
                    xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
                    _force_wall_view()

def action_search_hub():
    dialog = xbmcgui.Dialog()
    options = [
        '🔍  Universal Search (Movies, TV Shows & Streaming Exclusives)',
        '📺  Search TV Shows & Streaming Exclusives (Netflix, Apple, Disney+, HBO, Hulu...)',
        '🎬  Search Movies & Cinema Releases',
        '⚡  Browse Streaming Networks & Exclusives (Netflix, Disney+, Max, Apple, Hulu...)',
    ]
    sel = dialog.select('AntiVenom — Global Search & Exclusives', options)
    if sel == 0:
        action_universal_search()
    elif sel == 1:
        action_search_shows()
    elif sel == 2:
        action_search_movies()
    elif sel == 3:
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.thecrew/?action=tvNetworks,return)')
        _force_wall_view()

def action_movie_categories():
    dialog = xbmcgui.Dialog()
    cats = [
        ('Browse by Genre', 'plugin://plugin.video.thecrew/?action=movieGenres'),
        ('In Theaters Now', 'plugin://plugin.video.thecrew/?action=movies&url=theaters'),
        ('Most Popular Movies', 'plugin://plugin.video.thecrew/?action=movies&url=popular'),
        ('Oscar Award Winners', 'plugin://plugin.video.thecrew/?action=movies&url=oscars'),
        ('Box Office Hits', 'plugin://plugin.video.thecrew/?action=movies&url=boxoffice'),
        ('Movies by Year', 'plugin://plugin.video.thecrew/?action=movieYears'),
    ]
    sel = dialog.select('AntiVenom — Movie Categories', [c[0] for c in cats])
    if sel >= 0:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{cats[sel][1]},return)')
        _force_wall_view()

def action_tv_categories():
    dialog = xbmcgui.Dialog()
    cats = [
        ('Streaming Networks & Originals (Netflix, Hulu, Disney+, Max...)', 'plugin://plugin.video.thecrew/?action=tvNetworks'),
        ('Netflix Originals', 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=213'),
        ('Hulu Originals & Exclusives', 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=453'),
        ('Disney+ Originals', 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=2739'),
        ('HBO Max / Max Originals', 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=3186'),
        ('Apple TV+ Originals', 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=2552'),
        ('Amazon Prime Video', 'plugin://plugin.video.thecrew/?action=tvshows&url=tmdb_networks&tid=1024'),
        ('Browse by Genre', 'plugin://plugin.video.thecrew/?action=tvGenres'),
        ('Airing Today', 'plugin://plugin.video.thecrew/?action=tvshows&url=airing'),
        ('New Premieres', 'plugin://plugin.video.thecrew/?action=tvshows&url=premiere'),
        ('Most Popular TV Shows', 'plugin://plugin.video.thecrew/?action=tvshows&url=popular'),
        ('Highly Rated TV Shows', 'plugin://plugin.video.thecrew/?action=tvshows&url=rating'),
    ]
    sel = dialog.select('AntiVenom — TV Show Categories', [c[0] for c in cats])
    if sel >= 0:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{cats[sel][1]},return)')
        _force_wall_view()


def _force_wall_view(delay_ms=800):
    """Force Netflix-style Wall view (500) after ActivateWindow navigation."""
    # Use AlarmClock - survives script exit unlike threading
    xbmc.executebuiltin('AlarmClock(AntiVenomWallView,Container.SetViewMode(500),00:02,silent)')

def action_sports_live(sport=None):
    cats = {
        'nfl':      ('[LIVE] NFL Pro Football (Games & Sunday Ticket)',              'plugin://plugin.video.thecrew/?action=nfl'),
        'ncaa':     ('[LIVE] NCAA College Football (Saturday Gameday Feeds)',        'plugin://plugin.video.thecrew/?action=ncaa'),
        'nba':      ('[LIVE] NBA Pro Basketball (Matches & Feeds)',                  'plugin://plugin.video.thecrew/?action=nba'),
        'ncaab':    ('[LIVE] NCAA College Sports (Basketball, Hockey & Events)',     'plugin://plugin.video.thecrew/?action=ncaab'),
        'ufc':      ('[LIVE] UFC & MMA Fight Events (Live & Cards)',                 'plugin://plugin.video.thecrew/?action=ufc'),
        'fifa':     ('[LIVE] FIFA & European Soccer Live',                           'plugin://plugin.video.thecrew/?action=fifa'),
        'nhl':      ('[LIVE] NHL Hockey Live Games',                                 'plugin://plugin.video.thecrew/?action=nhl'),
        'mlb':      ('[LIVE] MLB Baseball Live Matches',                             'plugin://plugin.video.thecrew/?action=mlb'),
        'f1':       ('[LIVE] Formula 1 & Motorsports Live',                          'plugin://plugin.video.thecrew/?action=f1'),
        'boxing':   ('[LIVE] Boxing Live Events & Bouts',                            'plugin://plugin.video.thecrew/?action=boxing'),
        'nascar':   ('[LIVE] NASCAR & Motorsports Live',                             'plugin://plugin.video.thecrew/?action=f1'),
        'wwe':      ('[LIVE] WWE RAW & SmackDown',                                   'plugin://plugin.video.thecrew/?action=wwe'),
        'channels': ('[24/7] Live Cable Sports TV Networks',                         'plugin://plugin.video.thecrew/?action=sports_channels'),
        'all':      ('[ALL] All Sports Hub Directory',                               'plugin://plugin.video.thecrew/?action=bluehat'),
    }
    # Direct launch - no dialog - each card passes its sport key
    if sport and sport in cats:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{cats[sport][1]},return)')
        _force_wall_view()
        return
    # Fallback dialog (used by Explore Sports hero button)
    dialog = xbmcgui.Dialog()
    cat_list = list(cats.values())
    sel = dialog.select('AntiVenom — Live Sports & Schedules', [c[0] for c in cat_list])
    if sel >= 0:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{cat_list[sel][1]},return)')
        _force_wall_view()

def action_sports_replays():
    dialog = xbmcgui.Dialog()
    cats = [
        ('[REPLAY] Boxing HD Full Fight Replays', 'plugin://plugin.video.thecrew/?action=sreplays'),
        ('[REPLAY] UFC & MMA Full Event Replays', 'plugin://plugin.video.thecrew/?action=sreplays'),
        ('[REPLAY] WWE & Pro Wrestling Replays', 'plugin://plugin.video.thecrew/?action=wwe'),
        ('[REPLAY] NFL Game Replays & Highlights', 'plugin://plugin.video.thecrew/?action=sreplays'),
        ('[REPLAY] All On-Demand Sports Replays', 'plugin://plugin.video.thecrew/?action=sreplays'),
    ]
    sel = dialog.select('AntiVenom — Sports Replays & On-Demand', [c[0] for c in cats])
    if sel >= 0:
        xbmc.executebuiltin(f'ActivateWindow(Videos,{cats[sel][1]},return)')
        _force_wall_view()

# ─────────────────────────────────────────────
#  Step 7: In-App One-Click Update (Method C)
# ─────────────────────────────────────────────
def _get_installed_version():
    ver_file = os.path.join(ADDON_DATA, 'installed_version.txt')
    if os.path.exists(ver_file):
        try:
            with open(ver_file, 'r', encoding='utf-8') as f:
                v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    return ADDON.getAddonInfo('version')

def _set_installed_version(ver):
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        ver_file = os.path.join(ADDON_DATA, 'installed_version.txt')
        with open(ver_file, 'w', encoding='utf-8') as f:
            f.write(str(ver))
        xbmc.executebuiltin(f'Skin.SetString(AntiVenomVersion, {ver})')
    except Exception:
        pass

def action_check_update(manual=True):
    dialog = xbmcgui.Dialog()
    current_ver = _get_installed_version()
    log(f'Checking for updates... Current version: {current_ver}')

    progress = xbmcgui.DialogProgress()
    if manual:
        progress.create('AntiVenom Update Check', 'Connecting to GitHub Releases...')

    remote_ver = None
    zip_url = None
    changelog_text = ''

    # 1. Query GitHub Releases API directly (No repo needed, 100% works with standard releases!)
    try:
        req = urllib.request.Request(GITHUB_RELEASE_API, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        
        tag = data.get('tag_name', '').lstrip('v').strip()
        if tag:
            remote_ver = tag
            body = data.get('body', '').strip()
            changelog_text = body if body else 'Performance optimizations, fixed settings navigation, enlarged buttons, and Real-Debrid auto-vault.'
            for asset in data.get('assets', []):
                aname = asset.get('name', '').lower()
                if aname.endswith('.zip') and ('antivenom' in aname or 'script' in aname):
                    zip_url = asset.get('browser_download_url')
                    break
            if not zip_url and data.get('assets'):
                zip_url = data['assets'][0].get('browser_download_url')
    except Exception as e_gh:
        log(f'GitHub Release API error: {e_gh}')

    # 2. Fallback to raw version.json if GitHub API failed or had no zip
    if not zip_url:
        try:
            req = urllib.request.Request(UPDATE_URL, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=6) as resp:
                vdata = json.loads(resp.read().decode('utf-8'))
            remote_ver = vdata.get('version', remote_ver)
            zip_url = vdata.get('zip_url', zip_url)
            lines = vdata.get('changelog', [])
            if lines:
                changelog_text = '\n'.join([f'• {l}' for l in lines])
        except Exception as e_v:
            log(f'Version JSON fallback error: {e_v}')

    if manual:
        try:
            progress.close()
        except Exception:
            pass

    if not zip_url or not remote_ver:
        if manual:
            dialog.ok('Update Check', f'Unable to reach GitHub update server.\n\nInstalled Version: v{current_ver}\nPlease verify your internet connection.')
        return

    def parse_v(v):
        return [int(x) for x in re.sub(r'[^0-9.]', '', str(v)).split('.') if x]

    is_newer = parse_v(remote_ver) > parse_v(current_ver)

    if is_newer:
        confirm = dialog.yesno(
            '⚡ AntiVenom Update Available ⚡',
            f'[COLOR lime][B]A new version of AntiVenom is available![/B][/COLOR]\n\n'
            f'Installed: [B]v{current_ver}[/B]   -->   Latest: [COLOR cyan][B]v{remote_ver}[/B][/COLOR]\n\n'
            f'[B]What\'s New in this update:[/B]\n{changelog_text}\n\n'
            f'Would you like to download and install this update now?\n'
            f'[COLOR gray](All your settings and Real-Debrid logins are preserved)[/COLOR]',
            yeslabel='Update Now',
            nolabel='Later'
        )
        if confirm:
            perform_update(zip_url, remote_ver)
    else:
        if manual:
            reinstall = dialog.yesno(
                'AntiVenom is Up to Date',
                f'[COLOR lime][B]You are running the latest version (v{current_ver})![/B][/COLOR]\n\n'
                f'Would you like to force re-download and re-install this build to refresh all files?',
                yeslabel='Re-install',
                nolabel='Close'
            )
            if reinstall:
                perform_update(zip_url, remote_ver)

def perform_update(zip_url, remote_ver):
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    progress.create('Updating AntiVenom', f'Connecting to GitHub for v{remote_ver}...')

    tmp_zip = os.path.join(HOME_DIR, '_antivenom_update.zip')
    try:
        req = urllib.request.Request(zip_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as resp, open(tmp_zip, 'wb') as out_f:
            total_size = int(resp.headers.get('content-length', 0))
            count = 0
            block_size = 65536
            while True:
                chunk = resp.read(block_size)
                if not chunk:
                    break
                out_f.write(chunk)
                count += len(chunk)
                if total_size > 0:
                    percent = int(count * 85 / total_size)
                    progress.update(min(percent, 85), f'Downloading AntiVenom v{remote_ver}... ({percent}% of {total_size//(1024*1024)}MB)')
                else:
                    progress.update(45, f'Downloading AntiVenom v{remote_ver}... ({count//(1024*1024)}MB)')

        progress.update(90, 'Extracting and applying update...')
        with zipfile.ZipFile(tmp_zip, 'r') as zf:
            zf.extractall(ADDONS_DIR)

        if os.path.exists(tmp_zip):
            os.remove(tmp_zip)

        bundled_skin = os.path.join(ADDONS_DIR, 'script.antivenom', SKIN_ID)
        if os.path.isdir(bundled_skin):
            shutil.copytree(bundled_skin, SKIN_DEST, dirs_exist_ok=True)

        _set_installed_version(remote_ver)
        sync_realdebrid_vault()
        force_views()

        # Ensure skin.antivenom is enabled & activated in Kodi
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(500)
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.SetAddonEnabled',
            'params': {'addonid': SKIN_ID, 'enabled': True}
        }))
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin', 'value': SKIN_ID}
        }))

        # Write directly to guisettings.xml without default="true"
        guisettings = xbmcvfs.translatePath('special://masterprofile/guisettings.xml')
        if os.path.isfile(guisettings):
            content = open(guisettings, 'r', encoding='utf-8').read()
            import re
            content = re.sub(
                r'<setting id="lookandfeel\.skin"[^>]*>[^<]*</setting>',
                f'<setting id="lookandfeel.skin">{SKIN_ID}</setting>',
                content
            )
            open(guisettings, 'w', encoding='utf-8').write(content)

        # Auto-confirm Kodi's 15-second "Would you like to keep this change?" dialog
        for _ in range(8):
            xbmc.sleep(300)
            if xbmcgui.getCurrentWindowDialogId() == 10100:
                xbmc.executebuiltin('SendClick(11)') # YES
                break

        progress.update(100, 'Update complete! Refreshing interface...')
        xbmc.sleep(1000)
        progress.close()

        dialog.ok('Update Successful!', f'[COLOR lime][B]AntiVenom has been updated to v{remote_ver}![/B][/COLOR]\n\nThe skin has been refreshed with all new features.')
        xbmc.executebuiltin('ReloadSkin()')
    except Exception as e:
        if os.path.exists(tmp_zip):
            try: os.remove(tmp_zip)
            except Exception: pass
        progress.close()
        log(f'Update failed: {e}\n{traceback.format_exc()}')
        dialog.ok('Update Failed', f'Failed to install update: {e}')

# ─────────────────────────────────────────────
#  Entry Point
# ─────────────────────────────────────────────
#  Step 9: Resume Last Watched Media Action
# ─────────────────────────────────────────────
def action_resume_last_watched():
    try:
        resume_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/resume_state.json')
        if not os.path.isfile(resume_file):
            xbmcgui.Dialog().notification('AntiVenom', 'No resume point found', xbmcgui.NOTIFICATION_INFO, 3000)
            return

        with open(resume_file, 'r', encoding='utf-8') as f:
            state = json.load(f)

        title = state.get('title', 'Media')
        time_str = state.get('time_str', '0:00')
        seconds = state.get('seconds', 0)
        file_path = state.get('file', '')
        media_type = state.get('type', 'movie')

        dialog = xbmcgui.Dialog()
        choice = dialog.yesno(
            f'Resume {title}',
            f'You stopped watching at {time_str}.\n\nWould you like to resume where you left off or start over from the beginning?',
            yeslabel=f'Resume at {time_str}',
            nolabel='Start from Beginning'
        )

        if choice is None:
            return

        seek_target = seconds if choice else 0

        if file_path and not file_path.startswith('plugin://'):
            item = xbmcgui.ListItem(title)
            if seek_target > 0:
                item.setProperty('ResumeTime', str(seek_target))
            xbmc.Player().play(file_path, item)
            if seek_target > 0:
                def _seek():
                    for _ in range(30):
                        xbmc.sleep(200)
                        if xbmc.Player().isPlaying():
                            xbmc.sleep(500)
                            xbmc.Player().seekTime(float(seek_target))
                            break
                import threading
                threading.Thread(target=_seek).start()
        else:
            import urllib.parse
            if media_type == 'episode':
                target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(title)}'
            else:
                target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(title)}'
            xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
            _force_wall_view()
            if seek_target > 0:
                xbmcgui.Dialog().notification('AntiVenom Resume', f'Select your stream to resume at {time_str}', xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as e:
        xbmc.log(f'[AntiVenom] Resume error: {e}', xbmc.LOGWARNING)

def main():
    args = {}
    for arg in sys.argv[1:]:
        arg = arg.lstrip('?')
        for pair in arg.split('&'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                args[k] = v

    action = args.get('action')
    xbmc.log(f'[AntiVenom] default.py executed with action={action} args={args} sys.argv={sys.argv}', xbmc.LOGINFO)
    if action == 'setup_wizard':
        action_setup_wizard(first_run=args.get('first_run') == 'true')
    elif action == 'setup':
        action_setup()
    elif action == 'clean_cache':
        clean_system_cache(silent=False)
    elif action == 'check_update':
        action_check_update(manual=True)
    elif action == 'search_movies':
        action_search_movies()
    elif action == 'search_shows':
        action_search_shows()
    elif action in ['search', 'search_universal', 'universal_search']:
        action_universal_search()
    elif action == 'search_hub':
        action_search_hub()
    elif action == 'play_trending_movie':
        import urllib.parse
        title = args.get('title', 'Deadpool & Wolverine')
        target = f'plugin://plugin.video.thecrew/?action=movieSearchterm&name={urllib.parse.quote_plus(title)}'
        xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
        _force_wall_view()
    elif action == 'play_popular_show':
        import urllib.parse
        title = args.get('title', 'Stranger Things')
        target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(title)}'
        xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
        _force_wall_view()
    elif action == 'browse_network':
        import urllib.parse
        net = args.get('network', 'Netflix')
        target = f'plugin://plugin.video.thecrew/?action=tvSearchterm&name={urllib.parse.quote_plus(net)}'
        xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
        _force_wall_view()
    elif action == 'run_search':
        import urllib.parse
        term = args.get('name', '')
        media_type = args.get('type', 'shows')
        act = 'tvSearchterm' if media_type == 'shows' else 'movieSearchterm'
        target = f'plugin://plugin.video.thecrew/?action={act}&name={urllib.parse.quote_plus(term)}'
        if xbmcgui.getCurrentWindowId() == 10025:
            xbmc.executebuiltin(f'Container.Update({target})')
        else:
            xbmc.executebuiltin(f'ActivateWindow(Videos,{target},return)')
            _force_wall_view()
    elif action == 'movie_categories':
        action_movie_categories()
    elif action == 'tv_categories':
        action_tv_categories()
    elif action == 'sports_live':
        action_sports_live(sport=args.get('sport'))
    elif action == 'sports_replays':
        action_sports_replays()
    elif action == 'reload_skin':
        xbmc.executebuiltin('ReloadSkin()')
    elif action in ['resume_last_watched', 'resume_playback']:
        action_resume_last_watched()
    elif action == 'apply_resume':
        try:
            import service
            service.apply_resume_to_skin()
        except Exception as e:
            xbmc.log(f'[AntiVenom] apply_resume error: {e}', xbmc.LOGWARNING)
    elif action == 'take_screenshot':
        target_file = args.get('path', r'C:\Users\xelaa\.gemini\antigravity-ide\brain\3a8b4ca8-70cd-4752-a4c4-4276116322ca\kodi_live_render.png')
        xbmc.executebuiltin(f'TakeScreenshot("{target_file}",false)')
    elif action == 'manage_debrid':
        action_manage_debrid()
    elif action == 'close_dialogs':
        xbmc.executebuiltin('Dialog.Close(all,true)')
    elif action == 'set_tab':
        tab = args.get('tab', 'home')
        xbmc.executebuiltin(f'Skin.SetString(ActiveTab,{tab})')
        if tab == 'movies':
            xbmc.executebuiltin('SetFocus(6000)')
        elif tab == 'tvshows':
            xbmc.executebuiltin('SetFocus(7000)')
        elif tab == 'livetv':
            xbmc.executebuiltin('SetFocus(8000)')
        elif tab == 'sports':
            xbmc.executebuiltin('SetFocus(8500)')
        elif tab == 'favorites':
            xbmc.executebuiltin('SetFocus(9500)')
        else:
            xbmc.executebuiltin('SetFocus(5000)')
    else:
        # If launched while not running skin.antivenom, prompt to activate it immediately
        if xbmc.getSkinDir() != SKIN_ID:
            dialog = xbmcgui.Dialog()
            if dialog.yesno('AntiVenom Theme', 'The AntiVenom custom streaming interface is not active.\n\nWould you like to activate the AntiVenom theme now?', yeslabel='Activate Now', nolabel='Cancel'):
                install_skin()
                return
        # If already set up, open the settings menu. Otherwise run first-time setup.
        if os.path.exists(DONE_FLAG):
            action_setup()
        else:
            run_setup()

if __name__ == '__main__':
    main()

