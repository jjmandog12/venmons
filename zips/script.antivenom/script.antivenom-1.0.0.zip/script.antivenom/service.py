# -*- coding: utf-8 -*-
"""
AntiVenom Background Service
Ensures AntiVenom skin is always active and Real-Debrid authorization is permanently remembered.
"""
import xbmc
import xbmcgui
import xbmcvfs
import os
import shutil
import json
import xml.etree.ElementTree as ET

def ensure_skin_active():
    """Ensure skin.antivenom is deployed and actively running."""
    try:
        home_dir = xbmcvfs.translatePath('special://home/')
        addons_dir = os.path.join(home_dir, 'addons')
        skin_src = os.path.join(addons_dir, 'script.antivenom', 'skin.antivenom')
        skin_dest = os.path.join(addons_dir, 'skin.antivenom')

        # 1. Ensure skin.antivenom files are extracted and present in addons/
        if os.path.isdir(skin_src):
            if not os.path.isdir(skin_dest) or not os.path.isfile(os.path.join(skin_dest, 'addon.xml')):
                shutil.copytree(skin_src, skin_dest, dirs_exist_ok=True)
                xbmc.log('[AntiVenom] Service deployed skin.antivenom to addons folder!', xbmc.LOGINFO)
                xbmc.executebuiltin('UpdateLocalAddons')
                xbmc.sleep(1500)

        # 2. Check current active skin
        current_skin = xbmc.getSkinDir()
        xbmc.log(f'[AntiVenom] Service: active skin is {current_skin}', xbmc.LOGINFO)

        if current_skin != 'skin.antivenom':
            xbmc.log('[AntiVenom] Service: Default skin detected. Automatically switching to AntiVenom skin...', xbmc.LOGINFO)

            # Ensure skin.antivenom is enabled in Kodi
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': 'skin.antivenom', 'enabled': True}
            }))
            xbmc.sleep(500)

            # Update guisettings.xml directly without default="true"
            guisettings = xbmcvfs.translatePath('special://masterprofile/guisettings.xml')
            if os.path.isfile(guisettings):
                with open(guisettings, 'r', encoding='utf-8') as f:
                    content = f.read()
                import re
                if '<setting id="lookandfeel.skin"' in content:
                    content = re.sub(
                        r'<setting id="lookandfeel\.skin"[^>]*>[^<]*</setting>',
                        '<setting id="lookandfeel.skin">skin.antivenom</setting>',
                        content
                    )
                else:
                    content = content.replace('</settings>', '    <setting id="lookandfeel.skin">skin.antivenom</setting>\n</settings>')
                with open(guisettings, 'w', encoding='utf-8') as f:
                    f.write(content)

            # Trigger skin switch
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Settings.SetSettingValue',
                'params': {'setting': 'lookandfeel.skin', 'value': 'skin.antivenom'}
            }))

            # Auto-confirm Kodi's 15-second "Would you like to keep this change?" dialog
            for _ in range(8):
                xbmc.sleep(400)
                if xbmcgui.getCurrentWindowDialogId() == 10100:
                    xbmc.executebuiltin('SendClick(11)') # Click YES
                    break
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service skin activation error: {e}', xbmc.LOGWARNING)

def sync_rd():
    try:
        vault_file = xbmcvfs.translatePath('special://profile/addon_data/script.antivenom/rd_vault.json')
        resolveurl_settings = xbmcvfs.translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml')

        rd_keys = [
            'RealDebridResolver_token',
            'RealDebridResolver_refresh',
            'RealDebridResolver_client_id',
            'RealDebridResolver_client_secret',
            'RealDebridResolver_enabled',
            'RealDebridResolver_login',
            'RealDebridResolver_torrents',
            'RealDebridResolver_priority',
            'RealDebridResolver_cached_only'
        ]

        # 1. If ResolveURL has active credentials, back them up
        if os.path.isfile(resolveurl_settings):
            tree = ET.parse(resolveurl_settings)
            root = tree.getroot()
            token_node = None
            for s in root.findall('setting'):
                if s.attrib.get('id') == 'RealDebridResolver_token':
                    token_node = s
                    break

            if token_node is not None and token_node.text and 'default' not in token_node.attrib and token_node.text.strip():
                saved = {}
                for s in root.findall('setting'):
                    sid = s.attrib.get('id')
                    if sid in rd_keys and s.text:
                        saved[sid] = s.text.strip()
                if saved.get('RealDebridResolver_token'):
                    os.makedirs(os.path.dirname(vault_file), exist_ok=True)
                    with open(vault_file, 'w', encoding='utf-8') as f:
                        json.dump(saved, f, indent=4)
                    xbmc.executebuiltin('Skin.SetBool(RealDebridLinked)')
                    xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Active)')
                    return

        # 2. If ResolveURL is missing or lost token, restore from vault
        if os.path.isfile(vault_file) and os.path.isfile(resolveurl_settings):
            with open(vault_file, 'r', encoding='utf-8') as f:
                vault = json.load(f)
            token = vault.get('RealDebridResolver_token')
            if token and token.strip():
                tree = ET.parse(resolveurl_settings)
                root = tree.getroot()
                existing = {s.attrib.get('id'): s for s in root.findall('setting')}
                changed = False
                for k, v in vault.items():
                    if k in existing:
                        if existing[k].text != v:
                            existing[k].text = v
                            if 'default' in existing[k].attrib:
                                del existing[k].attrib['default']
                            changed = True
                    else:
                        el = ET.SubElement(root, 'setting', {'id': k})
                        el.text = v
                        changed = True
                if changed:
                    tree.write(resolveurl_settings, encoding='utf-8', xml_declaration=False)
                    xbmc.log('[AntiVenom] Service: RESTORED Real-Debrid credentials from vault!', xbmc.LOGINFO)
                xbmc.executebuiltin('Skin.SetBool(RealDebridLinked)')
                xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Active)')
                return

        # If neither has token
        xbmc.executebuiltin('Skin.Reset(RealDebridLinked)')
        xbmc.executebuiltin('Skin.SetString(RealDebridStatus, Unlinked)')
    except Exception as e:
        xbmc.log(f'[AntiVenom] Service RD sync error: {e}', xbmc.LOGWARNING)

if __name__ == '__main__':
    xbmc.log('[AntiVenom] Background service started', xbmc.LOGINFO)
    ensure_skin_active()
    sync_rd()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
        sync_rd()
