# -*- coding: utf-8 -*-
"""
AntiVenom Predictive Autocompletion Plugin for Kodi Virtual Keyboard
Provides high-speed, multi-source movie, TV show, and streaming suggestions
as the user types in DialogKeyboard.
"""

import sys
import os
import re
import json
import urllib.request
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

try:
    ADDON = xbmcaddon.Addon('plugin.program.autocompletion')
except Exception:
    ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

TMDB_KEY = '0049795edb57568b95240bc9e61a9dfc'
LOCAL_DICT_PATH = os.path.join(ADDON_PATH, 'resources', 'popular_titles.json')

# In-memory LRU / Session Cache
CACHE = {}
MAX_CACHE_SIZE = 128

# Load curated popular movie/show titles
LOCAL_TITLES = []
if os.path.exists(LOCAL_DICT_PATH):
    try:
        with open(LOCAL_DICT_PATH, 'r', encoding='utf-8') as f:
            LOCAL_TITLES = json.load(f)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Error loading popular_titles.json: {e}", xbmc.LOGERROR)

CLEAN_RE = re.compile(
    r'\b(trailer|official trailer|teaser|full movie|full episode|season \d+|episode \d+|theme|soundtrack|song|ost|interview|scene|gameplay|review|reaction)\b',
    re.IGNORECASE
)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def clean_youtube_title(text):
    text = CLEAN_RE.sub('', text)
    text = re.sub(r'[:\-\s]+$', '', text)
    text = re.sub(r'^\s*-\s*', '', text)
    text = re.sub(r'\s{2,}', ' ', text).strip()
    words = text.split()
    return ' '.join(w.capitalize() if not w.isupper() else w for w in words)


def fetch_imdb(query):
    results = []
    try:
        q_norm = query.strip().lower().replace(' ', '_')
        url = f"https://v3.sg.media-imdb.com/suggestion/x/{urllib.parse.quote_plus(q_norm)}.json"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=0.45) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        for item in data.get('d', []):
            q_type = item.get('q')
            if q_type in ('feature', 'movie', 'TV series', 'TV mini-series', 'TV movie', 'video', 'video game') or item.get('y'):
                title = item.get('l')
                if title:
                    results.append(title.strip())
    except Exception:
        pass
    return results


def fetch_tmdb(query):
    results = []
    try:
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_KEY}&query={urllib.parse.quote_plus(query.strip())}&include_adult=false"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=0.45) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        for item in data.get('results', []):
            if item.get('media_type') in ('movie', 'tv'):
                title = item.get('title') or item.get('name')
                if title:
                    results.append(title.strip())
    except Exception:
        pass
    return results


def fetch_youtube(query):
    results = []
    try:
        url = f"https://suggestqueries.google.com/complete/search?client=youtube&ds=yt&q={urllib.parse.quote_plus(query.strip())}"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=0.45) as resp:
            raw = resp.read().decode('utf-8', errors='ignore')
        match = re.search(r'\((.*)\)', raw)
        if match:
            data = json.loads(match.group(1))
            for item in data[1]:
                t = clean_youtube_title(item[0])
                if t and len(t) > 2:
                    results.append(t)
    except Exception:
        pass
    return results


def _score_title(title, query):
    t_low = title.lower()
    if t_low == query:
        return 110
    if t_low.startswith(query):
        return 90
    if any(word.startswith(query) for word in t_low.split()):
        return 70
    if query in t_low:
        return 50
    return 0


def get_suggestions(query, limit=9):
    q = query.strip().lower()
    if not q:
        return []

    if q in CACHE:
        return CACHE[q][:limit]

    candidates = {}

    # Local titles return before the next keystroke. Network lookups were
    # cancelled by Kodi because they took longer than the user kept typing.
    for title in LOCAL_TITLES:
        score = _score_title(title, q)
        if score:
            candidates[title] = max(candidates.get(title, 0), score + 10)

    if len(candidates) < limit:
        for title in fetch_youtube(query):
            score = _score_title(title, q) or 40
            candidates[title] = max(candidates.get(title, 0), score)

    # Deduplicate preserving highest ranked entries
    seen_lower = set()
    ranked = []
    sorted_items = sorted(candidates.items(), key=lambda x: (x[1], -len(x[0])), reverse=True)

    for title, score in sorted_items:
        t_low = title.lower().strip()
        if t_low == q and len(sorted_items) > 1:
            continue
        if t_low not in seen_lower:
            seen_lower.add(t_low)
            ranked.append(title)
            if len(ranked) >= limit:
                break

    # Update cache
    if len(CACHE) >= MAX_CACHE_SIZE:
        CACHE.clear()
    CACHE[q] = ranked

    return ranked[:limit]


def parse_params(raw_args):
    params = {}
    if not raw_args:
        return params
    if raw_args.startswith('?'):
        raw_args = raw_args[1:]
    
    # Support both && and & delimiters
    normalized = raw_args.replace('&&', '&')
    for part in normalized.split('&'):
        if '=' in part:
            k, v = part.split('=', 1)
            params[k.strip().lower()] = urllib.parse.unquote_plus(v.strip())
        elif part.strip():
            params[part.strip().lower()] = ''
    return params


def handle_autocomplete(handle, params):
    if xbmc.getCondVisibility("System.HasHiddenInput"):
        xbmcplugin.endOfDirectory(handle=handle, succeeded=True)
        return

    query = params.get('id', '').strip()
    limit = int(params.get('limit', 9))

    if not query:
        xbmcplugin.endOfDirectory(handle=handle, succeeded=True)
        return

    suggestions = get_suggestions(query, limit=limit)
    log(f"autocomplete '{query}' -> {len(suggestions)}")
    items = []

    for idx, title in enumerate(suggestions):
        li = xbmcgui.ListItem(label=title)
        path = title
        li.setPath(path)
        li.setProperty('path', path)
        li.setProperty('index', str(idx))
        li.setProperty('isPlayable', 'false')
        items.append((path, li, False))

    if items:
        xbmcplugin.addDirectoryItems(handle=handle, items=items, totalItems=len(items))
    xbmcplugin.endOfDirectory(handle=handle, succeeded=True)


def handle_selectautocomplete(params):
    handle = params.get('handle')
    if handle:
        try:
            xbmcplugin.setResolvedUrl(handle=int(handle), succeeded=False, listitem=xbmcgui.ListItem())
        except Exception:
            pass

    selected_text = params.get('id', '').strip()
    if not selected_text:
        return

    log(f"handle_selectautocomplete selected: '{selected_text}'")

    # Send selected text to DialogKeyboard and submit search immediately
    xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Input.SendText",
        "params": {
            "text": selected_text,
            "done": True
        },
        "id": 1
    }))
    try:
        xbmc.executebuiltin("Control.SetFocus(300)")
    except Exception:
        pass


def run():
    try:
        handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
        raw_args = sys.argv[2] if len(sys.argv) > 2 else ''
        params = parse_params(raw_args)
        if handle != -1:
            params['handle'] = handle

        info = params.get('info', '')
        if info == 'autocomplete' and handle != -1:
            handle_autocomplete(handle, params)
        elif info == 'selectautocomplete':
            handle_selectautocomplete(params)
        else:
            if handle != -1:
                xbmcplugin.endOfDirectory(handle=handle, succeeded=True)
    except Exception as e:
        log(f"Exception in plugin.program.autocompletion: {e}", xbmc.LOGERROR)
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            try:
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            except Exception:
                pass


if __name__ == '__main__':
    run()
